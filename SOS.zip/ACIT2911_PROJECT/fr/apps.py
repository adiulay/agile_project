from django.apps import AppConfig


class FrConfig(AppConfig):
    name = 'fr'
